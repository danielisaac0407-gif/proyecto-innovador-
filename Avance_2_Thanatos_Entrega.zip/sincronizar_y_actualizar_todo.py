import subprocess
import os
import sys

def sincronizar_todo():
    print("="*75)
    print("SINCRONIZACIÓN AUTOMÁTICA: PÁGINA WEB -> DATASET -> MODELOS ML")
    print("="*75)
    
    # Paso 1: Extraer de catalogo_funerarias.html con Node.js
    print("\n[Paso 1/3] Extrayendo base de datos 'db' de 'catalogo_funerarias.html'...")
    import extraer_catalogo
    extraer_catalogo.extraer()
    
    # Paso 2: Regenerar Dataset de Cotizaciones
    print("\n[Paso 2/3] Regenerando dataset con base en los ítems y precios de la página...")
    import generador_dataset_pagina
    generador_dataset_pagina.generar_dataset_desde_pagina()
    
    # Paso 3: Re-entrenar modelos de Machine Learning y actualizar métricas
    print("\n[Paso 3/3] Re-entrenando modelos de la Unidad 3 y actualizando tablas...")
    import pipeline_ml_pagina
    pipeline_ml_pagina.ejecutar_pipeline_ml_pagina()
    
    print("\n" + "="*75)
    print("¡SINCRONIZACIÓN COMPLETADA CON ÉXITO!")
    print("Los cambios de tu página web ya están reflejados en el pipeline de ML.")
    print("="*75)

if __name__ == '__main__':
    sincronizar_todo()
