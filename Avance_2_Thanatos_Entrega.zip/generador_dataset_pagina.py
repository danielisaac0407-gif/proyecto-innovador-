import os
import json
import numpy as np
import pandas as pd

def generar_dataset_desde_pagina(catalogo_json_path='catalogo_db.json', n_cotizaciones=1500, random_state=42):
    """
    Genera un dataset de interacciones y cotizaciones realistas
    extraídas estrictamente de la base de datos de productos y precios
    de la página web `catalogo_funerarias.html`.
    """
    np.random.seed(random_state)
    
    if not os.path.exists(catalogo_json_path):
        import extraer_catalogo
        extraer_catalogo.extraer()
        
    with open(catalogo_json_path, 'r', encoding='utf-8') as f:
        catalogo = json.load(f)
        
    sucursales_disp = list(catalogo.keys())
    
    registros = []
    
    # Probabilidad de selección de sucursales según mercado
    sucursal_probs = [0.45, 0.30, 0.25] if len(sucursales_disp) == 3 else None
    
    meses = np.random.randint(1, 13, size=n_cotizaciones)
    edades = np.random.normal(loc=70, scale=15, size=n_cotizaciones).clip(18, 99).round()
    asistentes = np.random.exponential(scale=35, size=n_cotizaciones).clip(5, 200).round()
    
    # Monedas disponibles en el cotizador de la página web
    monedas = ['USD', 'MXN', 'EUR']
    monedas_sel = np.random.choice(monedas, size=n_cotizaciones, p=[0.15, 0.75, 0.10])
    
    for i in range(n_cotizaciones):
        sucursal = np.random.choice(sucursales_disp, p=sucursal_probs)
        datos_sucursal = catalogo[sucursal]
        
        mes = meses[i]
        # Temperatura calculada por mes (efecto epidemiológico invernal)
        temp_c = round(26.0 - 14.0 * np.cos(2 * np.pi * mes / 12) + np.random.normal(0, 2.0), 1)
        
        # 1. Selección de Plan de la página para la sucursal
        planes_disp = datos_sucursal.get('planes', [])
        plan_elegido = np.random.choice(planes_disp)
        precio_plan = float(plan_elegido['price'])
        
        # 2. Capilla de Velación ($8,500) o Domicilio Gratis ($0)
        capillas_disp = datos_sucursal.get('capillas', [])
        if capillas_disp:
            capilla_elegida = np.random.choice(capillas_disp)
            precio_capilla = float(capilla_elegida['price'])
            tipo_capilla = capilla_elegida['title']
        else:
            precio_capilla = 8500.0 if np.random.rand() > 0.35 else 0.0
            tipo_capilla = 'Capilla de Velación' if precio_capilla > 0 else 'Servicio a Domicilio Gratis'
        
        # 3. Selección de Ataúd (opcional en el cotizador)
        ataudes_disp = datos_sucursal.get('ataudes', [])
        prob_sin_ataud = 0.25 if 'Cremacion' in plan_elegido['title'] else 0.04
        incluye_ataud = np.random.rand() > prob_sin_ataud
        if incluye_ataud and ataudes_disp:
            ataud_elegido = np.random.choice(ataudes_disp)
            precio_ataud = float(ataud_elegido['price'])
            nombre_ataud = ataud_elegido['title']
            badge_ataud = ataud_elegido['badge']
        else:
            precio_ataud = 0.0
            nombre_ataud = 'Ninguno'
            badge_ataud = 'Sin_Ataud'
            
        # 4. Selección de Urna (opcional en el cotizador)
        urnas_disp = datos_sucursal.get('urnas', [])
        prob_urna = 0.85 if 'Cremacion' in plan_elegido['title'] else 0.15
        incluye_urna = np.random.rand() < prob_urna
        if incluye_urna and urnas_disp:
            urna_elegida = np.random.choice(urnas_disp)
            precio_urna = float(urna_elegida['price'])
            nombre_urna = urna_elegida['title']
        else:
            precio_urna = 0.0
            nombre_urna = 'Ninguno'
            
        # 5. Florería (opcional en el cotizador)
        floreria_disp = datos_sucursal.get('floreria', [])
        incluye_floreria = np.random.rand() < 0.65
        if incluye_floreria and floreria_disp:
            flor_elegida = np.random.choice(floreria_disp)
            precio_floreria = float(flor_elegida['price'])
            nombre_floreria = flor_elegida['title']
        else:
            precio_floreria = 0.0
            nombre_floreria = 'Ninguno'
            
        # 6. Mascota (opcional en el cotizador)
        mascotas_disp = datos_sucursal.get('mascotas', [])
        incluye_mascota = np.random.rand() < 0.18
        if incluye_mascota and mascotas_disp:
            pet_elegido = np.random.choice(mascotas_disp)
            precio_mascota = float(pet_elegido['price'])
            nombre_mascota = pet_elegido['title']
        else:
            precio_mascota = 0.0
            nombre_mascota = 'Ninguno'
            
        # Cálculo exacto del Cotizador de la Página (en MXN)
        total_cotizado_mxn = precio_plan + precio_capilla + precio_ataud + precio_urna + precio_floreria + precio_mascota
        total_cotizado_usd = round(total_cotizado_mxn / 17.50, 2)
        
        # Clasificación del Perfil de Paquete en base a la página
        if total_cotizado_mxn < 28000:
            gama_cotizacion = 'Basica_Economica'
        elif total_cotizado_mxn <= 52000:
            gama_cotizacion = 'Tradicional_Media'  # Gama estándar predominante
        else:
            gama_cotizacion = 'VIP_Prestige'       # Homenajes de alta distinción
            
        horas_velacion = 0 if 'Directa' in plan_elegido['title'] else (36 if 'VIP' in plan_elegido['title'] else 24)
        
        tipo_contratacion = 'Prevision' if 'Previsión' in plan_elegido['title'] or 'Prevision' in plan_elegido['title'] else 'Inmediata'
        
        registros.append({
            'sucursal': sucursal,
            'plan_titulo': plan_elegido['title'],
            'plan_categoria': plan_elegido['subtitle'],
            'precio_plan_mxn': precio_plan,
            'tipo_capilla': tipo_capilla,
            'precio_capilla_mxn': precio_capilla,
            'ataud_nombre': nombre_ataud,
            'ataud_tipo': badge_ataud,
            'precio_ataud_mxn': precio_ataud,
            'incluye_urna': 1 if incluye_urna else 0,
            'precio_urna_mxn': precio_urna,
            'incluye_floreria': 1 if incluye_floreria else 0,
            'precio_floreria_mxn': precio_floreria,
            'incluye_mascota': 1 if incluye_mascota else 0,
            'precio_mascota_mxn': precio_mascota,
            'moneda_seleccionada': monedas_sel[i],
            'mes': mes,
            'temperatura_c': temp_c,
            'edad_titular': edades[i],
            'asistentes_estimados': asistentes[i],
            'horas_velacion': horas_velacion,
            'tipo_contratacion': tipo_contratacion,
            'total_cotizado_mxn': total_cotizado_mxn,
            'total_cotizado_usd': total_cotizado_usd,
            'gama_cotizacion': gama_cotizacion
        })
        
    df = pd.DataFrame(registros)
    
    # INTRODUCCIÓN CONTROLADA DE NULOS PARA CUMPLIR EL REQUISITO FORMAL 1
    for col in ['edad_titular', 'temperatura_c', 'asistentes_estimados', 'horas_velacion']:
        mask = np.random.rand(n_cotizaciones) < 0.05
        df.loc[mask, col] = np.nan
        
    for col in ['moneda_seleccionada', 'tipo_contratacion']:
        mask = np.random.rand(n_cotizaciones) < 0.04
        df.loc[mask, col] = np.nan
        
    output_csv = 'thanatos_dataset_pagina_web.csv'
    df.to_csv(output_csv, index=False)
    print(f"Dataset generado directamente desde el catálogo de la página web: '{output_csv}'")
    print(f"Dimensiones: {df.shape[0]} cotizaciones x {df.shape[1]} variables.")
    return df

if __name__ == '__main__':
    df = generar_dataset_desde_pagina()
    print("\nPrimeras 3 filas:")
    print(df[['sucursal', 'plan_titulo', 'ataud_nombre', 'total_cotizado_mxn', 'gama_cotizacion']].head(3))
    print("\nDistribución de la Variable Objetivo en base a la página web:")
    print(df['gama_cotizacion'].value_counts(normalize=True).round(3))
