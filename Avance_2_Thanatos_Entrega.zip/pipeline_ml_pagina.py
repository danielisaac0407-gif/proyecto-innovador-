import os
import sys
import warnings
warnings.filterwarnings('ignore')

import numpy as np

# Compatibilidad transparente NumPy 1.26 con SciPy 1.13+ / Scikit-Learn
if not hasattr(np, 'long'):
    np.long = int
if not hasattr(np, 'ulong'):
    np.ulong = int

orig_array = np.array
def safe_np_array(object, dtype=None, copy=True, order='K', subok=False, ndmin=0, **kwargs):
    if copy is None:
        copy = False
    return orig_array(object, dtype=dtype, copy=copy, order=order, subok=subok, ndmin=ndmin, **kwargs)
np.array = safe_np_array

import pandas as pd
from sklearn.model_selection import train_test_split, cross_validate, StratifiedKFold
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.naive_bayes import GaussianNB
from sklearn.neighbors import KNeighborsClassifier, KNeighborsRegressor
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier, DecisionTreeRegressor
from sklearn.linear_model import LinearRegression
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    confusion_matrix, classification_report,
    mean_squared_error, mean_absolute_error, r2_score
)

def ejecutar_pipeline_ml_pagina(csv_path='thanatos_dataset_pagina_web.csv'):
    print("="*78)
    print("THANATOS ANALYTICS - PROYECTO INTEGRADOR (E0 - E2)")
    print("AVANCE 2: PREPROCESAMIENTO, PARTICIÓN Y ENTRENAMIENTO DE MODELOS ML")
    print("="*78)
    
    if not os.path.exists(csv_path):
        import generador_dataset_pagina
        df = generador_dataset_pagina.generar_dataset_desde_pagina()
    else:
        df = pd.read_csv(csv_path)
        
    print(f"\n[1] DATASET CARGADO: '{csv_path}'")
    print(f"Dimensiones: {df.shape[0]} cotizaciones x {df.shape[1]} columnas")
    print("\nDistribución de la Variable Objetivo de la Página Web (gama_cotizacion):")
    for cls, cnt in df['gama_cotizacion'].value_counts().items():
        pct = (cnt / len(df)) * 100
        print(f"  • {cls:<20}: {cnt:4d} cotizaciones ({pct:.1f}%)")
        
    print("\nValores Nulos Detectados (previo a imputación):")
    nulos = df.isnull().sum()
    for col, cnt in nulos[nulos > 0].items():
        print(f"  • {col:<22}: {cnt:3d} nulos ({cnt/len(df)*100:.1f}%)")

    # =========================================================================
    # 1. PREPROCESAMIENTO E INGENIERÍA DE CARACTERÍSTICAS
    # =========================================================================
    features_clf = [
        'sucursal', 'moneda_seleccionada', 'tipo_contratacion', 'tipo_capilla', 'ataud_tipo',
        'mes', 'temperatura_c', 'edad_titular', 'asistentes_estimados', 'horas_velacion',
        'incluye_urna', 'incluye_floreria', 'incluye_mascota',
        'precio_plan_mxn', 'precio_capilla_mxn', 'precio_ataud_mxn', 
        'precio_urna_mxn', 'precio_floreria_mxn', 'precio_mascota_mxn'
    ]
    
    X = df[features_clf]
    y = df['gama_cotizacion']
    
    num_cols = [
        'mes', 'temperatura_c', 'edad_titular', 'asistentes_estimados', 'horas_velacion',
        'precio_plan_mxn', 'precio_capilla_mxn', 'precio_ataud_mxn', 
        'precio_urna_mxn', 'precio_floreria_mxn', 'precio_mascota_mxn'
    ]
    cat_cols = [
        'sucursal', 'moneda_seleccionada', 'tipo_contratacion', 'tipo_capilla', 'ataud_tipo',
        'incluye_urna', 'incluye_floreria', 'incluye_mascota'
    ]
    
    num_pipeline = Pipeline(steps=[
        ('imputer', SimpleImputer(strategy='median')),
        ('scaler', StandardScaler())
    ])
    
    cat_pipeline = Pipeline(steps=[
        ('imputer', SimpleImputer(strategy='most_frequent')),
        ('onehot', OneHotEncoder(handle_unknown='ignore', sparse_output=False))
    ])
    
    preprocessor = ColumnTransformer(transformers=[
        ('num', num_pipeline, num_cols),
        ('cat', cat_pipeline, cat_cols)
    ])

    # =========================================================================
    # 2. PARTICIÓN DE DATOS (TRAIN 80% / TEST 20%)
    # =========================================================================
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=42, stratify=y
    )
    
    print("\n" + "="*78)
    print("[2] PARTICIÓN FORMAL DE DATOS:")
    print(f"  • Muestras de Entrenamiento (Train 80%): {X_train.shape[0]} observaciones")
    print(f"  • Muestras de Prueba        (Test 20%):  {X_test.shape[0]} observaciones")
    print(f"  • Estratificación:                       Preservada según proporciones de clases")
    print(f"  • Validación Cruzada Complementaria:     Stratified 5-Fold Cross Validation")
    print("="*78)

    # =========================================================================
    # 3. ENTRENAMIENTO DE MODELOS DE CLASIFICACIÓN (UNIDAD 3)
    # =========================================================================
    models_clf = {
        'Gaussian Naive Bayes': GaussianNB(),
        'K-Nearest Neighbors (KNN, k=7)': KNeighborsClassifier(n_neighbors=7, weights='distance'),
        'Support Vector Machine (SVM RBF)': SVC(kernel='rbf', C=1.5, gamma='scale', random_state=42),
        'Árbol de Decisión (CART, max_d=5)': DecisionTreeClassifier(max_depth=5, min_samples_split=10, random_state=42)
    }

    results_clf = []
    skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    trained_pipes = {}

    for name, clf in models_clf.items():
        pipe = Pipeline(steps=[
            ('preprocessor', preprocessor),
            ('classifier', clf)
        ])
        
        # 5-Fold Stratified Cross Validation
        scoring = ['accuracy', 'precision_weighted', 'recall_weighted', 'f1_weighted']
        cv = cross_validate(pipe, X_train, y_train, cv=skf, scoring=scoring, n_jobs=1)
        
        # Ajuste en Train y Evaluación en Test
        pipe.fit(X_train, y_train)
        trained_pipes[name] = pipe
        y_pred = pipe.predict(X_test)
        
        results_clf.append({
            'Algoritmo (Unidad 3)': name,
            'Accuracy': round(accuracy_score(y_test, y_pred), 4),
            'Precision (Weighted)': round(precision_score(y_test, y_pred, average='weighted', zero_division=0), 4),
            'Recall (Weighted)': round(recall_score(y_test, y_pred, average='weighted', zero_division=0), 4),
            'F1-Score (Weighted)': round(f1_score(y_test, y_pred, average='weighted', zero_division=0), 4),
            'F1-Score (Macro)': round(f1_score(y_test, y_pred, average='macro', zero_division=0), 4),
            'CV 5-Fold Acc (Media)': round(cv['test_accuracy'].mean(), 4),
            'CV 5-Fold Acc (Std)': round(cv['test_accuracy'].std(), 4)
        })

    df_results_clf = pd.DataFrame(results_clf)
    print("\n[3 & 4] TABLA COMPARATIVA DE RENDIMIENTO (CLASIFICACIÓN GAMA COTIZADA):")
    print(df_results_clf.to_string(index=False))

    # Matriz de Confusión para el modelo ganador
    best_name = df_results_clf.sort_values(by='F1-Score (Weighted)', ascending=False).iloc[0]['Algoritmo (Unidad 3)']
    best_pipe = trained_pipes[best_name]
    y_pred_best = best_pipe.predict(X_test)
    labels = sorted(list(y.unique()))
    cm = confusion_matrix(y_test, y_pred_best, labels=labels)
    df_cm = pd.DataFrame(cm, index=[f"Real_{l}" for l in labels], columns=[f"Pred_{l}" for l in labels])
    
    print(f"\nMatriz de Confusión del Mejor Modelo [{best_name}]:")
    print(df_cm)
    print("\nReporte Detallado de Clasificación:")
    print(classification_report(y_test, y_pred_best, target_names=labels, digits=4))

    # =========================================================================
    # 4. ENFOQUE DE REGRESIÓN: PREDICCIÓN DEL TOTAL COTIZADO EN LA PÁGINA ($ MXN)
    # =========================================================================
    print("\n" + "="*78)
    print("[ENFOQUE DE REGRESIÓN] PREDICCIÓN DEL TOTAL COTIZADO EN EL SITIO WEB (MXN)")
    print("="*78)
    
    features_reg = [
        'precio_plan_mxn', 'precio_capilla_mxn', 'precio_ataud_mxn', 'incluye_urna', 'precio_urna_mxn',
        'incluye_floreria', 'precio_floreria_mxn', 'incluye_mascota', 'precio_mascota_mxn',
        'horas_velacion', 'asistentes_estimados', 'temperatura_c'
    ]
    
    # Imputar previamente para la regresión
    df_clean_reg = df[features_reg + ['total_cotizado_mxn']].copy()
    imputer_reg = SimpleImputer(strategy='median')
    df_clean_reg[features_reg] = imputer_reg.fit_transform(df_clean_reg[features_reg])
    
    X_reg = df_clean_reg[features_reg]
    y_reg = df_clean_reg['total_cotizado_mxn']
    
    X_r_train, X_r_test, y_r_train, y_r_test = train_test_split(X_reg, y_reg, test_size=0.20, random_state=42)
    
    scaler_r = StandardScaler()
    X_r_train_s = scaler_r.fit_transform(X_r_train)
    X_r_test_s = scaler_r.transform(X_r_test)
    
    # A) OLS Manual Matricial: beta = (X^T X)^(-1) X^T y
    X_mat_tr = np.hstack([np.ones((X_r_train_s.shape[0], 1)), X_r_train_s])
    X_mat_te = np.hstack([np.ones((X_r_test_s.shape[0], 1)), X_r_test_s])
    beta_man = np.linalg.inv(X_mat_tr.T @ X_mat_tr) @ X_mat_tr.T @ y_r_train.values
    y_r_pred_man = X_mat_te @ beta_man
    
    # B) Scikit-Learn LinearRegression
    lr = LinearRegression()
    lr.fit(X_r_train_s, y_r_train)
    y_r_pred_sk = lr.predict(X_r_test_s)
    
    # C) KNN Regressor
    knnr = KNeighborsRegressor(n_neighbors=5, weights='distance')
    knnr.fit(X_r_train_s, y_r_train)
    y_r_pred_knn = knnr.predict(X_r_test_s)
    
    # D) Decision Tree Regressor
    dtr = DecisionTreeRegressor(max_depth=5, random_state=42)
    dtr.fit(X_r_train_s, y_r_train)
    y_r_pred_dt = dtr.predict(X_r_test_s)
    
    reg_models = {
        'OLS Matricial Normal Eq (Manual NumPy)': y_r_pred_man,
        'Linear Regression (Scikit-Learn)': y_r_pred_sk,
        'Decision Tree Regressor (depth=5)': y_r_pred_dt,
        'KNN Regressor (k=5)': y_r_pred_knn
    }
    
    results_reg = []
    for name, pred in reg_models.items():
        rmse = np.sqrt(mean_squared_error(y_r_test, pred))
        mae = mean_absolute_error(y_r_test, pred)
        r2 = r2_score(y_r_test, pred)
        results_reg.append({
            'Modelo de Regresión': name,
            'RMSE ($ MXN)': round(rmse, 2),
            'MAE ($ MXN)': round(mae, 2),
            'R² (Varianza Explicada)': round(r2, 4)
        })
        
    df_results_reg = pd.DataFrame(results_reg)
    print("\nTABLA COMPARATIVA DE MODELOS DE REGRESIÓN (TOTAL COTIZADOR EN LA PÁGINA):")
    print(df_results_reg.to_string(index=False))

    # Exportar resultados formales
    df_results_clf.to_csv('tabla_comparativa_clasificacion_pagina.csv', index=False)
    df_results_reg.to_csv('tabla_comparativa_regresion_pagina.csv', index=False)
    df_cm.to_csv('matriz_confusion_pagina.csv')
    print("\nArchivos exportados exitosamente a CSV.")
    return df_results_clf, df_results_reg, df_cm

if __name__ == '__main__':
    ejecutar_pipeline_ml_pagina()
